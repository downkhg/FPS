using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 일시정지 화면 GUI 프리팹 컴포넌트
/// 컨텍스트(GUIManager)의 이벤트 함수를 UI 컨트롤에 바인딩합니다.
/// 음량 조절, 타이틀 복귀 및 종료 확인은 GUIManager -> GuiPopupManager를 통해 팝업으로 처리합니다.
/// </summary>
public class PauseGuiScene : GuiSceneBase
{
    [Header("Pause Buttons")]
    [SerializeField]
    private Button m_btnResume;

    [SerializeField]
    private Button m_btnRestart;

    [SerializeField]
    private Button m_btnAudioSettings;

    [SerializeField]
    private Button m_btnTitle;

    [SerializeField]
    private Button m_btnQuit;

    public override void Initialize(GUIManager _cManager)
    {
        base.Initialize(_cManager);
        if (m_cManager == null) return;

        if (m_btnResume != null)
        {
            m_btnResume.onClick.RemoveAllListeners();
            m_btnResume.onClick.AddListener(m_cManager.ResumeGame);
        }

        if (m_btnRestart != null)
        {
            m_btnRestart.onClick.RemoveAllListeners();
            m_btnRestart.onClick.AddListener(m_cManager.RestartGame);
        }

        if (m_btnAudioSettings != null)
        {
            m_btnAudioSettings.onClick.RemoveAllListeners();
            m_btnAudioSettings.onClick.AddListener(m_cManager.OpenAudioSettingPopup);
        }

        if (m_btnTitle != null)
        {
            m_btnTitle.onClick.RemoveAllListeners();
            m_btnTitle.onClick.AddListener(m_cManager.RequestReturnToTitle);
        }

        if (m_btnQuit != null)
        {
            m_btnQuit.onClick.RemoveAllListeners();
            m_btnQuit.onClick.AddListener(m_cManager.RequestQuitGame);
        }
    }
}
