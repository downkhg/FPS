using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent(typeof(Rigidbody))]
public class PlayerMovementScript : MonoBehaviour {
	Rigidbody rb;

	[Tooltip("Current players speed")]
	public float currentSpeed;
	[Tooltip("Force that moves player into jump")]
	public float jumpForce = 500;
	[Tooltip("Position of the camera inside the player")]
	[HideInInspector]public Vector3 cameraPosition;

	[Header("Marionette / NPC Sync Settings")]
	[Tooltip("카메라가 없을 때(NPC) 플레이어의 Forward를 기준으로 키보드 입력에 맞춰 함께 이동할지 여부")]
	public bool syncMovementWithPlayer = true;
	[Tooltip("기준으로 삼을 플레이어 Transform (비워두면 GameManager.instance.CurrentPlayer 참조)")]
	public Transform referencePlayerTransform;

	private Player playerComponent;

	// 마리오네트 제어를 위한 입력 캐싱
	private Vector2 currentInputMove;
	private Vector3 currentWorldMove;
	private bool hasWorldMove = false;
	private bool isCrouching = false;

	/*
	 * Getting the Players rigidbody component.
	 * And grabbing the mainCamera from Players child transform.
	 */
	void Awake(){
		rb = GetComponent<Rigidbody>();
		playerComponent = GetComponent<Player>();
		ignoreLayer = 1 << LayerMask.NameToLayer ("Player");

		if (!bulletSpawn)
		{
			Transform foundSpawn = transform.Find("BulletSpawn");
			if (foundSpawn) bulletSpawn = foundSpawn;
			else bulletSpawn = this.transform;
		}
	}

    private void Initialize(Transform mianCamera, Transform _bulletSpawn)
    {
        rb = GetComponent<Rigidbody>();
		playerComponent = GetComponent<Player>();
		if (_bulletSpawn) bulletSpawn = _bulletSpawn;
        ignoreLayer = 1 << LayerMask.NameToLayer("Player");
    }

    private Vector3 slowdownV;
	private Vector2 horizontalMovement;

	/*
	* Raycasting for meele attacks and input movement handling here.
	*/
	void FixedUpdate(){
		RaycastForMeleeAttacks ();

		PlayerMovementLogic ();
	}

	/*
	* Accordingly to input adds force and if magnitude is bigger it will clamp it.
	* If player leaves keys it will deaccelerate
	*/
	void PlayerMovementLogic(){
		currentSpeed = rb.linearVelocity.magnitude;
		horizontalMovement = new Vector2 (rb.linearVelocity.x, rb.linearVelocity.z);
		if (horizontalMovement.magnitude > maxSpeed){
			horizontalMovement = horizontalMovement.normalized;
			horizontalMovement *= maxSpeed;    
		}
		rb.linearVelocity = new Vector3 (
			horizontalMovement.x,
			rb.linearVelocity.y,
			horizontalMovement.y
		);
		if (grounded){
			rb.linearVelocity = Vector3.SmoothDamp(rb.linearVelocity,
				new Vector3(0,rb.linearVelocity.y,0),
				ref slowdownV,
				deaccelerationSpeed);
		}

		float hInput = currentInputMove.x;
		float vInput = currentInputMove.y;
		float forceMultiplier = grounded ? accelerationSpeed : (accelerationSpeed / 2f);

		if (hasWorldMove)
		{
			// [AI 컨트롤러 / 월드 방향 이동]
			Vector3 moveDir = Vector3.ProjectOnPlane(currentWorldMove, Vector3.up).normalized;
			rb.AddForce(moveDir * forceMultiplier * Time.deltaTime, ForceMode.Force);

			deaccelerationSpeed = (currentWorldMove.sqrMagnitude > 0.01f) ? 0.5f : 0.1f;
		}
		else
		{
			// [플레이어 컨트롤러 / 로컬 축 기준 이동]
			rb.AddRelativeForce (hInput * forceMultiplier * Time.deltaTime, 0, vInput * forceMultiplier * Time.deltaTime);

			if (hInput != 0 || vInput != 0) {
				deaccelerationSpeed = 0.5f;
			} else {
				deaccelerationSpeed = 0.1f;
			}
		}
	}

	// ==================== 마리오네트 제어 API ====================

	public void SetInputMove(Vector2 moveInput)
	{
		hasWorldMove = false;
		currentInputMove = moveInput;
	}

	public void SetWorldMove(Vector3 worldDirection)
	{
		hasWorldMove = true;
		currentWorldMove = worldDirection;
		currentInputMove = new Vector2(worldDirection.x, worldDirection.z);
	}

	public void DoJump()
	{
		if (grounded) {
			rb.AddRelativeForce (Vector3.up * jumpForce);
			if (_jumpSound)
				_jumpSound.Play ();
			if (_walkSound) _walkSound.Stop ();
			if (_runSound) _runSound.Stop ();
		}
	}

	public void DoCrouch(bool enable)
	{
		isCrouching = enable;
	}

	void Update(){
		CrouchingProcess();
		WalkingSound ();
	}

	void CrouchingProcess(){
		if(isCrouching){
			transform.localScale = Vector3.Lerp(transform.localScale, new Vector3(1,0.6f,1), Time.deltaTime * 15);
		}
		else{
			transform.localScale = Vector3.Lerp(transform.localScale, new Vector3(1,1,1), Time.deltaTime * 15);
		}
	}

	/*
	* Checks if player is grounded and plays the sound accorindlgy to his speed
	*/
	void WalkingSound(){
		if (_walkSound && _runSound) {
			if (RayCastGrounded ()) {			
				if (currentSpeed > 1) {
					if (maxSpeed == 3) {
						if (!_walkSound.isPlaying) {
							_walkSound.Play ();
							_runSound.Stop ();
						}					
					} else if (maxSpeed == 5) {
						if (!_runSound.isPlaying) {
							_walkSound.Stop ();
							_runSound.Play ();
						}
					}
				} else {
					_walkSound.Stop ();
					_runSound.Stop ();
				}
			} else {
				_walkSound.Stop ();
				_runSound.Stop ();
			}
		}
	}

	private bool RayCastGrounded(){
		RaycastHit groundedInfo;
		if(Physics.Raycast(transform.position, transform.up *-1f, out groundedInfo, 1, ~ignoreLayer)){
			Debug.DrawRay (transform.position, transform.up * -1f, Color.red, 0.0f);
			if(groundedInfo.transform != null){
				return true;
			}
			else{
				return false;
			}
		}

		return false;
	}

	[Tooltip("The maximum speed you want to achieve")]
	public int maxSpeed = 5;
	[Tooltip("The higher the number the faster it will stop")]
	public float deaccelerationSpeed = 15.0f;


	[Tooltip("Force that is applied when moving forward or backward")]
	public float accelerationSpeed = 50000.0f;


	[Tooltip("Tells us weather the player is grounded or not.")]
	public bool grounded;

	void OnCollisionStay(Collision other){
		foreach(ContactPoint contact in other.contacts){
			if(Vector2.Angle(contact.normal,Vector3.up) < 60){
				grounded = true;
			}
		}
	}

	void OnCollisionExit ()
	{
		grounded = false;
	}


	RaycastHit hitInfo;
	private float meleeAttack_cooldown;
	private string currentWeapo;
	[Tooltip("Put 'Player' layer here")]
	[Header("Shooting Properties")]
	private LayerMask ignoreLayer;
	Ray ray1, ray2, ray3, ray4, ray5, ray6, ray7, ray8, ray9;
	private float rayDetectorMeeleSpace = 0.15f;
	private float offsetStart = 0.05f;
	[Tooltip("Put BulletSpawn gameobject here, palce from where bullets are created.")]
	public Transform bulletSpawn;

	public bool been_to_meele_anim = false;
	private void RaycastForMeleeAttacks(){
		if (bulletSpawn == null) return;

		if (meleeAttack_cooldown > -5) {
			meleeAttack_cooldown -= 1 * Time.deltaTime;
		}

		GunScript gs = playerComponent ? playerComponent.Gun : null;
		if (gs != null) {
			currentWeapo = "gun";
		}

		//middle row
		ray1 = new Ray (bulletSpawn.position + (bulletSpawn.right*offsetStart), bulletSpawn.forward + (bulletSpawn.right * rayDetectorMeeleSpace));
		ray2 = new Ray (bulletSpawn.position - (bulletSpawn.right*offsetStart), bulletSpawn.forward - (bulletSpawn.right * rayDetectorMeeleSpace));
		ray3 = new Ray (bulletSpawn.position, bulletSpawn.forward);
		//upper row
		ray4 = new Ray (bulletSpawn.position + (bulletSpawn.right*offsetStart) + (bulletSpawn.up*offsetStart), bulletSpawn.forward + (bulletSpawn.right * rayDetectorMeeleSpace) + (bulletSpawn.up * rayDetectorMeeleSpace));
		ray5 = new Ray (bulletSpawn.position - (bulletSpawn.right*offsetStart) + (bulletSpawn.up*offsetStart), bulletSpawn.forward - (bulletSpawn.right * rayDetectorMeeleSpace) + (bulletSpawn.up * rayDetectorMeeleSpace));
		ray6 = new Ray (bulletSpawn.position + (bulletSpawn.up*offsetStart), bulletSpawn.forward + (bulletSpawn.up * rayDetectorMeeleSpace));
		//bottom row
		ray7 = new Ray (bulletSpawn.position + (bulletSpawn.right*offsetStart) - (bulletSpawn.up*offsetStart), bulletSpawn.forward + (bulletSpawn.right * rayDetectorMeeleSpace) - (bulletSpawn.up * rayDetectorMeeleSpace));
		ray8 = new Ray (bulletSpawn.position - (bulletSpawn.right*offsetStart) - (bulletSpawn.up*offsetStart), bulletSpawn.forward - (bulletSpawn.right * rayDetectorMeeleSpace) - (bulletSpawn.up * rayDetectorMeeleSpace));
		ray9 = new Ray (bulletSpawn.position -(bulletSpawn.up*offsetStart), bulletSpawn.forward - (bulletSpawn.up * rayDetectorMeeleSpace));

		Debug.DrawRay (ray1.origin, ray1.direction, Color.cyan);
		Debug.DrawRay (ray2.origin, ray2.direction, Color.cyan);
		Debug.DrawRay (ray3.origin, ray3.direction, Color.cyan);
		Debug.DrawRay (ray4.origin, ray4.direction, Color.red);
		Debug.DrawRay (ray5.origin, ray5.direction, Color.red);
		Debug.DrawRay (ray6.origin, ray6.direction, Color.red);
		Debug.DrawRay (ray7.origin, ray7.direction, Color.yellow);
		Debug.DrawRay (ray8.origin, ray8.direction, Color.yellow);
		Debug.DrawRay (ray9.origin, ray9.direction, Color.yellow);

		if (gs != null) {
			if (gs.meeleAttack == false) {
				been_to_meele_anim = false;
			}
			if (gs.meeleAttack == true && been_to_meele_anim == false) {
				been_to_meele_anim = true;
				StartCoroutine ("MeeleAttackWeaponHit");
			}
		}

	}

	IEnumerator MeeleAttackWeaponHit(){
		if (Physics.Raycast (ray1, out hitInfo, 2f, ~ignoreLayer) || Physics.Raycast (ray2, out hitInfo, 2f, ~ignoreLayer) || Physics.Raycast (ray3, out hitInfo, 2f, ~ignoreLayer)
			|| Physics.Raycast (ray4, out hitInfo, 2f, ~ignoreLayer) || Physics.Raycast (ray5, out hitInfo, 2f, ~ignoreLayer) || Physics.Raycast (ray6, out hitInfo, 2f, ~ignoreLayer)
			|| Physics.Raycast (ray7, out hitInfo, 2f, ~ignoreLayer) || Physics.Raycast (ray8, out hitInfo, 2f, ~ignoreLayer) || Physics.Raycast (ray9, out hitInfo, 2f, ~ignoreLayer)) {
			if (hitInfo.transform.tag=="Dummie") {
				Transform _other = hitInfo.transform.root.transform;
				if (_other.transform.tag == "Dummie") {
					print ("hit a dummie");
				}
				InstantiateBlood(hitInfo,false);
			}
		}
		yield return new WaitForEndOfFrame ();
	}

	[Header("BloodForMelleAttaacks")]
	RaycastHit hit;
	[Tooltip("Put your particle blood effect here.")]
	public GameObject bloodEffect;

	void InstantiateBlood (RaycastHit _hitPos,bool swordHitWithGunOrNot) {		

		if (currentWeapo == "gun") {
			GunScript.HitMarkerSound ();

			if (_hitSound)
				_hitSound.Play ();
			else
				print ("Missing hit sound");
			
			if (!swordHitWithGunOrNot) {
				if (bloodEffect)
					Instantiate (bloodEffect, _hitPos.point, Quaternion.identity);
				else
					print ("Missing blood effect prefab in the inspector.");
			}
		} 
	}
	private GameObject myBloodEffect;


	[Header("Player SOUNDS")]
	[Tooltip("Jump sound when player jumps.")]
	public AudioSource _jumpSound;
	[Tooltip("Sound while player makes when successfully reloads weapon.")]
	public AudioSource _freakingZombiesSound;
	[Tooltip("Sound Bullet makes when hits target.")]
	public AudioSource _hitSound;
	[Tooltip("Walk sound player makes.")]
	public AudioSource _walkSound;
	[Tooltip("Run Sound player makes.")]
	public AudioSource _runSound;

    private void OnDrawGizmos()
    {
		Gizmos.color = Color.blue;
        Gizmos.DrawCube(this.transform.position, Vector2.one);
    }
}
