using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] MouseLookScript mls;
    [SerializeField] Transform mainCamera;
    [SerializeField] Camera secondCamera;
    [SerializeField] Transform player;
    [SerializeField] Camera cameraComponent;
    [SerializeField] Transform gunPlaceHolder;
    [SerializeField] PlayerMovementScript pmS;
    [SerializeField] GameObject bulletSpawnPlace;
    [SerializeField] AudioSource hitMarker;
    [SerializeField] TextMesh HUD_bullets;
    [SerializeField] GameObject weapon;
    [SerializeField] GunScript gun;
    [SerializeField] GunInventory gunInventory;
    [SerializeField] MouseLookScript MouseLookScript;

    // Public Getters
    public MouseLookScript Mls => mls;
    public Transform MainCamera => mainCamera;
    public Camera SecondCamera => secondCamera;
    public Transform Player => player;
    public Camera CameraComponent => cameraComponent;
    public Transform GunPlaceHolder => gunPlaceHolder;
    public PlayerMovementScript PmS => pmS;
    public GameObject BulletSpawnPlace => bulletSpawnPlace;
    public AudioSource HitMarker => hitMarker;
    public TextMesh HudBullets => HUD_bullets;
    public GameObject Weapon => weapon;
    public GunScript Gun => gun;

    public static GameManager instance;

    public static GameManager returm;

    private void Initialize()
    {
        gunInventory.Initialize();
        MouseLookScript.Initialize();
    }

    private void Awake()
    {
        //Initialize();
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        instance = this;
    }

    // Update is called once per frame
    void Update()
    {
        if(gunInventory && gunInventory.currentGun)
        {
            if(!hitMarker)
                hitMarker = gunInventory.currentGun.transform.Find("hitMarkerSound").GetComponent<AudioSource>();
            if (!gun)
                gun = gunInventory.currentGun.GetComponent<GunScript>();
        }
    }
}