using UnityEngine;

/// <summary>
/// 각 GUI 화면(씬) 객체의 추상 기반 클래스
/// Unity 인스펙터 직렬화 및 컨텍스트(GUIManager) 참조/공통 동작을 지원합니다.
/// </summary>
public abstract class GuiSceneBase : MonoBehaviour, IGuiScene
{
    [Header("GUI Scene Type")]
    [SerializeField]
    protected EGuiState m_eStateType;

    // 컨텍스트(GUI 관리자) 참조
    protected GUIManager m_cManager;

    /// <summary>
    /// 비활성(Inactive) 상태에서도 Awake() 호출 여부와 무관하게 정확한 상태를 반환하기 위한 고유 상태 프로퍼티
    /// </summary>
    public abstract EGuiState DefaultStateType { get; }

    public virtual EGuiState StateType => DefaultStateType;
    public bool IsActive => gameObject.activeSelf;

    protected virtual void Reset()
    {
        m_eStateType = DefaultStateType;
    }

    protected virtual void OnValidate()
    {
        m_eStateType = DefaultStateType;
    }

    public virtual void Initialize(GUIManager _cManager)
    {
        m_eStateType = DefaultStateType;
        m_cManager = _cManager;
    }

    public virtual void OnEnter()
    {
        SetActive(true);
    }

    public virtual void OnExit()
    {
        SetActive(false);
    }

    public virtual void SetActive(bool _bActive)
    {
        if (gameObject.activeSelf != _bActive)
        {
            gameObject.SetActive(_bActive);
        }
    }
}
