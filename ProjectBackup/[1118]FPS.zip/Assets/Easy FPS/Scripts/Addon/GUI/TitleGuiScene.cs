using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// 시작(타이틀) 화면 GUI 컴포넌트
/// 컨텍스트(GUIManager)의 이벤트 함수를 UI 컨트롤에 바인딩하고 사운드 설정 UI를 동기화합니다.
/// </summary>
public class TitleGuiScene : GuiSceneBase, IAudioSyncableGui
{
    [Header("Title Buttons")]
    [SerializeField]
    private Button m_btnStart;

    [SerializeField]
    private Button m_btnQuit;

    [Header("Title Audio Settings")]
    [SerializeField]
    private Slider m_sliderBgm;

    [SerializeField]
    private Slider m_sliderSfx;

    [SerializeField]
    private Toggle m_toggleMute;

    [SerializeField]
    private TextMeshProUGUI m_txtBgmValue;

    [SerializeField]
    private TextMeshProUGUI m_txtSfxValue;

    public override EGuiState DefaultStateType => EGuiState.Title;

    public override void Initialize(GUIManager _cManager)
    {
        base.Initialize(_cManager);
        if (m_cManager == null) return;

        if (m_btnStart != null)
        {
            m_btnStart.onClick.RemoveAllListeners();
            m_btnStart.onClick.AddListener(m_cManager.StartGame);
        }

        if (m_btnQuit != null)
        {
            m_btnQuit.onClick.RemoveAllListeners();
            m_btnQuit.onClick.AddListener(m_cManager.QuitGame);
        }

        if (m_sliderBgm != null)
        {
            m_sliderBgm.onValueChanged.RemoveAllListeners();
            m_sliderBgm.onValueChanged.AddListener(m_cManager.OnBgmSliderChanged);
        }

        if (m_sliderSfx != null)
        {
            m_sliderSfx.onValueChanged.RemoveAllListeners();
            m_sliderSfx.onValueChanged.AddListener(m_cManager.OnSfxSliderChanged);
        }

        if (m_toggleMute != null)
        {
            m_toggleMute.onValueChanged.RemoveAllListeners();
            m_toggleMute.onValueChanged.AddListener(m_cManager.OnMuteToggleChanged);
        }
    }

    public void SyncAudioSettings(float _fBgmVolume, float _fSfxVolume, bool _bIsMuted)
    {
        if (m_sliderBgm != null && !Mathf.Approximately(m_sliderBgm.value, _fBgmVolume))
        {
            m_sliderBgm.SetValueWithoutNotify(_fBgmVolume);
        }

        if (m_sliderSfx != null && !Mathf.Approximately(m_sliderSfx.value, _fSfxVolume))
        {
            m_sliderSfx.SetValueWithoutNotify(_fSfxVolume);
        }

        if (m_toggleMute != null && m_toggleMute.isOn != _bIsMuted)
        {
            m_toggleMute.SetIsOnWithoutNotify(_bIsMuted);
        }

        if (m_txtBgmValue != null)
        {
            m_txtBgmValue.text = string.Format("BGM Volume: {0}%", Mathf.RoundToInt(_fBgmVolume * 100f));
        }

        if (m_txtSfxValue != null)
        {
            m_txtSfxValue.text = string.Format("SFX Volume: {0}%", Mathf.RoundToInt(_fSfxVolume * 100f));
        }
    }
}
