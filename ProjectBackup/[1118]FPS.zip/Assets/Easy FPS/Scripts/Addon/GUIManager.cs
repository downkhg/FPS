using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum EGuiState
{
    Title,      // 시작(타이틀) 화면
    InGame,     // 인게임 HUD 화면
    Pause,      // 일시정지 및 환경설정 화면
    GameOver    // 게임오버 화면
}

public class GUIManager : MonoBehaviour
{
    public static GUIManager s_cInstance;

    // 씬 리로드 시 타이틀을 건너뛰고 바로 인게임으로 진입할지 여부 (Restart 기능용)
    private static bool s_bStartInGameOnReload = false;

    [Header("GUI State")]
    [SerializeField]
    private EGuiState m_eCurrentState = EGuiState.Title;

    [Header("GUI Scene Architecture (Polymorphism)")]
    [SerializeField]
    private Canvas m_canvasMain;

    [SerializeField]
    private List<GuiSceneBase> m_listSceneObjects = new List<GuiSceneBase>();

    // 런타임 다형성 제어용 인터페이스 통합 자료구조
    private readonly List<IGuiScene> m_listGuiScenes = new List<IGuiScene>();
    private readonly Dictionary<EGuiState, IGuiScene> m_dictGuiScenes = new Dictionary<EGuiState, IGuiScene>();

    [Header("Audio System Settings")]
    [SerializeField]
    private AudioSource m_asBgm;

    [SerializeField]
    private AudioSource m_asUiClick;

    [SerializeField, Range(0f, 1f)]
    private float m_fBgmVolume = 0.5f;

    [SerializeField, Range(0f, 1f)]
    private float m_fSfxVolume = 0.8f;

    [SerializeField]
    private bool m_bIsMuted = false;

    private readonly Dictionary<AudioSource, float> m_dictSfxBaseVolumes = new Dictionary<AudioSource, float>();
    private bool m_bIsInitialized = false;

    private const string PREF_BGM_VOL = "FPS_BGM_VOLUME";
    private const string PREF_SFX_VOL = "FPS_SFX_VOLUME";
    private const string PREF_MUTE = "FPS_AUDIO_MUTE";

    // ==================== 프로퍼티 ====================
    public EGuiState CurrentState => m_eCurrentState;
    public bool IsGameplayActive => m_eCurrentState == EGuiState.InGame;
    public float BgmVolume => m_fBgmVolume;
    public float SfxVolume => m_fSfxVolume;
    public bool IsMuted => m_bIsMuted;

    public static bool CanProcessGameplayInput()
    {
        return s_cInstance == null || s_cInstance.IsGameplayActive;
    }

    private void Awake()
    {
        if (s_cInstance != null && s_cInstance != this)
        {
            Destroy(this);
            return;
        }
        s_cInstance = this;
    }

    private void Start()
    {
        if (!m_bIsInitialized)
        {
            Initialize();
        }
    }

    public void Initialize()
    {
        if (m_bIsInitialized) return;
        m_bIsInitialized = true;

        s_cInstance = this;

        LoadAudioPreferences();
        EnsureAudioSources();
        InitializeGuiScenes();
        RefreshSfxSources();
        SyncAudioUiControls();

        if (s_bStartInGameOnReload)
        {
            s_bStartInGameOnReload = false;
            SetGuiState(EGuiState.InGame);
        }
        else
        {
            SetGuiState(EGuiState.Title);
        }
    }

    /// <summary>
    /// 개별 GUI 씬 객체들을 인터페이스 컬렉션으로 초기화하고 컨텍스트(this)를 전달합니다.
    /// </summary>
    private void InitializeGuiScenes()
    {
        m_listGuiScenes.Clear();
        m_dictGuiScenes.Clear();

        if (m_listSceneObjects == null)
        {
            m_listSceneObjects = new List<GuiSceneBase>();
        }
        else
        {
            m_listSceneObjects.RemoveAll(cItem => cItem == null);
        }

        if (m_canvasMain == null)
        {
            m_canvasMain = FindFirstObjectByType<Canvas>();
        }

        // 인스펙터 리스트가 비어있다면 Canvas 하위에서 자동 수집
        if (m_listSceneObjects.Count == 0 && m_canvasMain != null)
        {
            GuiSceneBase[] arrFoundScenes = m_canvasMain.GetComponentsInChildren<GuiSceneBase>(true);
            for (int i = 0; i < arrFoundScenes.Length; i++)
            {
                if (arrFoundScenes[i] != null && !m_listSceneObjects.Contains(arrFoundScenes[i]))
                {
                    m_listSceneObjects.Add(arrFoundScenes[i]);
                }
            }
        }

        // 리스트를 순회하며 인터페이스 컬렉션 등록 및 컨텍스트 참조 초기화
        for (int i = 0; i < m_listSceneObjects.Count; i++)
        {
            GuiSceneBase cScene = m_listSceneObjects[i];
            if (cScene == null) continue;

            if (!m_listGuiScenes.Contains(cScene))
            {
                m_listGuiScenes.Add(cScene);
            }
            m_dictGuiScenes[cScene.StateType] = cScene;
            cScene.Initialize(this);
        }
    }

    private void Update()
    {
        // ESC 키로 인게임 <-> 일시정지 토글
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (m_eCurrentState == EGuiState.InGame || m_eCurrentState == EGuiState.Pause)
            {
                TogglePause();
            }
        }

        // 인게임 중 테스트용 데미지/게임오버 단축키 (K키: 자가 피격 테스트)
        if (m_eCurrentState == EGuiState.InGame && Input.GetKeyDown(KeyCode.K))
        {
            if (GameManager.s_cInstance != null && GameManager.s_cInstance.CurrentPlayer != null)
            {
                GameManager.s_cInstance.CurrentPlayer.TakeDamage(50f);
            }
        }
    }

    // ==================== 화면 전환 및 UI 이벤트 핸들러 (컨텍스트 함수) ====================

    /// <summary>
    /// 지정한 GUI 상태로 화면을 전환하고 Time.timeScale 및 마우스 커서 상태를 제어합니다.
    /// </summary>
    public void SetGuiState(EGuiState _eNewState)
    {
        if (!m_bIsInitialized)
        {
            Initialize();
        }

        m_eCurrentState = _eNewState;

        // 인터페이스 기반 각 씬 활성화/비활성화 및 라이프사이클 호출
        for (int i = 0; i < m_listGuiScenes.Count; i++)
        {
            IGuiScene cScene = m_listGuiScenes[i];
            if (cScene == null) continue;

            if (cScene.StateType == _eNewState)
            {
                cScene.OnEnter();
            }
            else
            {
                cScene.OnExit();
            }
        }

        bool bIsInGame = (_eNewState == EGuiState.InGame);

        // 3D 탄약 HUD 텍스트 가시성 연동
        if (GameManager.s_cInstance != null && GameManager.s_cInstance.HudBullets != null)
        {
            MeshRenderer mrHud = GameManager.s_cInstance.HudBullets.GetComponent<MeshRenderer>();
            if (mrHud != null)
            {
                mrHud.enabled = bIsInGame;
            }
        }

        if (bIsInGame)
        {
            Time.timeScale = 1f;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            RefreshSfxSources();
        }
        else
        {
            Time.timeScale = 0f;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            StopLoopingCharacterSounds();
        }

        SyncAudioUiControls();
    }

    /// <summary>
    /// [시작 화면] -> [인게임] 전환 이벤트 핸들러
    /// </summary>
    public void StartGame()
    {
        PlayUiClickSound();
        SetGuiState(EGuiState.InGame);
    }

    /// <summary>
    /// 인게임 <-> 일시정지 토글
    /// </summary>
    public void TogglePause()
    {
        if (m_eCurrentState == EGuiState.InGame)
        {
            PauseGame();
        }
        else if (m_eCurrentState == EGuiState.Pause)
        {
            ResumeGame();
        }
    }

    /// <summary>
    /// [인게임] -> [일시정지] 전환 이벤트 핸들러
    /// </summary>
    public void PauseGame()
    {
        if (m_eCurrentState != EGuiState.InGame) return;
        PlayUiClickSound();
        SetGuiState(EGuiState.Pause);
    }

    /// <summary>
    /// [일시정지] -> [인게임] 복귀 이벤트 핸들러
    /// </summary>
    public void ResumeGame()
    {
        if (m_eCurrentState != EGuiState.Pause) return;
        PlayUiClickSound();
        SetGuiState(EGuiState.InGame);
    }

    /// <summary>
    /// 플레이어 사망 시 [게임오버] 화면으로 전환
    /// </summary>
    public void ShowGameOver(string _strReason = "MISSION FAILED - YOU DIED")
    {
        if (!m_bIsInitialized)
        {
            Initialize();
        }

        if (m_eCurrentState == EGuiState.GameOver) return;

        if (m_dictGuiScenes.TryGetValue(EGuiState.GameOver, out IGuiScene cScene) && cScene is GameOverGuiScene cGameOver)
        {
            cGameOver.ShowGameOver(_strReason);
        }

        SetGuiState(EGuiState.GameOver);
    }

    /// <summary>
    /// 현재 씬을 재시작하고 즉시 인게임 상태로 진입하는 이벤트 핸들러
    /// </summary>
    public void RestartGame()
    {
        PlayUiClickSound();
        Time.timeScale = 1f;
        s_bStartInGameOnReload = true;
        Scene sActiveScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(sActiveScene.buildIndex);
    }

    /// <summary>
    /// 현재 씬을 초기 상태로 리로드하고 시작(타이틀) 화면으로 돌아가는 이벤트 핸들러
    /// </summary>
    public void ReturnToTitle()
    {
        PlayUiClickSound();
        Time.timeScale = 1f;
        s_bStartInGameOnReload = false;
        Scene sActiveScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(sActiveScene.buildIndex);
    }

    /// <summary>
    /// 게임을 종료하는 이벤트 핸들러 (에디터 플레이 모드 종료 및 빌드 애플리케이션 종료 지원)
    /// </summary>
    public void QuitGame()
    {
        PlayUiClickSound();
        Time.timeScale = 1f;
        PlayerPrefs.Save();

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    /// <summary>
    /// BGM 슬라이더 값 변경 UI 이벤트 핸들러
    /// </summary>
    public void OnBgmSliderChanged(float _fVolume)
    {
        SetBgmVolume(_fVolume);
    }

    /// <summary>
    /// SFX 슬라이더 값 변경 UI 이벤트 핸들러
    /// </summary>
    public void OnSfxSliderChanged(float _fVolume)
    {
        SetSfxVolume(_fVolume);
    }

    /// <summary>
    /// 음소거(Mute) 토글 값 변경 UI 이벤트 핸들러
    /// </summary>
    public void OnMuteToggleChanged(bool _bMute)
    {
        PlayUiClickSound();
        SetMute(_bMute);
    }

    // ==================== 사운드 및 시스템 연동 함수 ====================

    /// <summary>
    /// 배경음악(BGM) 볼륨을 조절합니다 (0.0 ~ 1.0).
    /// </summary>
    public void SetBgmVolume(float _fVolume)
    {
        m_fBgmVolume = Mathf.Clamp01(_fVolume);

        if (m_asBgm != null)
        {
            m_asBgm.volume = m_bIsMuted ? 0f : m_fBgmVolume;
        }

        PlayerPrefs.SetFloat(PREF_BGM_VOL, m_fBgmVolume);
        SyncAudioUiControls();
    }

    /// <summary>
    /// 효과음(SFX) 볼륨을 조절합니다 (0.0 ~ 1.0).
    /// </summary>
    public void SetSfxVolume(float _fVolume)
    {
        m_fSfxVolume = Mathf.Clamp01(_fVolume);
        ApplySfxVolumeToAllSources();

        PlayerPrefs.SetFloat(PREF_SFX_VOL, m_fSfxVolume);
        SyncAudioUiControls();
    }

    /// <summary>
    /// 전체 사운드 음소거(Mute) 여부를 설정합니다.
    /// </summary>
    public void SetMute(bool _bMute)
    {
        m_bIsMuted = _bMute;
        AudioListener.volume = m_bIsMuted ? 0f : 1f;

        if (m_asBgm != null)
        {
            m_asBgm.volume = m_bIsMuted ? 0f : m_fBgmVolume;
        }

        ApplySfxVolumeToAllSources();

        PlayerPrefs.SetInt(PREF_MUTE, m_bIsMuted ? 1 : 0);
        SyncAudioUiControls();
    }

    /// <summary>
    /// 씬 내 모든 효과음 AudioSource를 탐색하여 원래 볼륨 대비 SFX 볼륨 비율을 적용합니다.
    /// </summary>
    public void RefreshSfxSources()
    {
        AudioSource[] arrAllSources = FindObjectsByType<AudioSource>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < arrAllSources.Length; i++)
        {
            AudioSource asTarget = arrAllSources[i];
            if (asTarget == null || asTarget == m_asBgm) continue;

            if (!m_dictSfxBaseVolumes.ContainsKey(asTarget))
            {
                float fBaseVol = asTarget.volume > 0.01f ? asTarget.volume : 1f;
                m_dictSfxBaseVolumes.Add(asTarget, fBaseVol);
            }
        }

        ApplySfxVolumeToAllSources();
    }

    private void ApplySfxVolumeToAllSources()
    {
        List<AudioSource> listDeadRefs = null;

        foreach (KeyValuePair<AudioSource, float> kvp in m_dictSfxBaseVolumes)
        {
            if (kvp.Key == null)
            {
                if (listDeadRefs == null) listDeadRefs = new List<AudioSource>();
                listDeadRefs.Add(kvp.Key);
                continue;
            }

            kvp.Key.volume = m_bIsMuted ? 0f : (kvp.Value * m_fSfxVolume);
        }

        if (listDeadRefs != null)
        {
            for (int i = 0; i < listDeadRefs.Count; i++)
            {
                m_dictSfxBaseVolumes.Remove(listDeadRefs[i]);
            }
        }

        if (m_asUiClick != null)
        {
            m_asUiClick.volume = m_bIsMuted ? 0f : m_fSfxVolume;
        }
    }

    private void StopLoopingCharacterSounds()
    {
        foreach (KeyValuePair<AudioSource, float> kvp in m_dictSfxBaseVolumes)
        {
            if (kvp.Key != null && kvp.Key.isPlaying && kvp.Key != m_asUiClick)
            {
                kvp.Key.Stop();
            }
        }
    }

    public void PlayUiClickSound()
    {
        if (m_asUiClick != null && m_asUiClick.clip != null && !m_bIsMuted)
        {
            m_asUiClick.PlayOneShot(m_asUiClick.clip, m_fSfxVolume);
        }
    }

    // ==================== 인게임 HUD 갱신 함수 ====================

    public void UpdateHpUi(float _fCurrentHp, float _fMaxHp)
    {
        if (!m_bIsInitialized)
        {
            Initialize();
        }

        if (m_dictGuiScenes.TryGetValue(EGuiState.InGame, out IGuiScene cScene) && cScene is InGameGuiScene cInGame)
        {
            cInGame.UpdateHp(_fCurrentHp, _fMaxHp);
        }
    }

    public void UpdateAmmoUi(string _strWeaponName, float _fBulletsInGun, float _fBulletsTotal)
    {
        if (!m_bIsInitialized)
        {
            Initialize();
        }

        if (m_dictGuiScenes.TryGetValue(EGuiState.InGame, out IGuiScene cScene) && cScene is InGameGuiScene cInGame)
        {
            cInGame.UpdateAmmo(Mathf.RoundToInt(_fBulletsInGun), Mathf.RoundToInt(_fBulletsTotal));
        }
    }

    // ==================== 내부 오디오 설정 및 동기화 ====================

    private void LoadAudioPreferences()
    {
        m_fBgmVolume = PlayerPrefs.GetFloat(PREF_BGM_VOL, m_fBgmVolume);
        m_fSfxVolume = PlayerPrefs.GetFloat(PREF_SFX_VOL, m_fSfxVolume);
        m_bIsMuted = PlayerPrefs.GetInt(PREF_MUTE, 0) == 1;
        AudioListener.volume = m_bIsMuted ? 0f : 1f;
    }

    private void SyncAudioUiControls()
    {
        // 통합 인터페이스(IAudioSyncableGui)를 구현한 모든 씬 객체에 오디오 설정 일괄 동기화
        for (int i = 0; i < m_listGuiScenes.Count; i++)
        {
            if (m_listGuiScenes[i] is IAudioSyncableGui cAudioSyncable)
            {
                cAudioSyncable.SyncAudioSettings(m_fBgmVolume, m_fSfxVolume, m_bIsMuted);
            }
        }
    }

    private void EnsureAudioSources()
    {
        if (m_asBgm == null)
        {
            Transform trBgm = transform.Find("BGM_AudioSource");
            if (trBgm != null)
            {
                m_asBgm = trBgm.GetComponent<AudioSource>();
            }
            if (m_asBgm == null)
            {
                GameObject objBgm = new GameObject("BGM_AudioSource");
                objBgm.transform.SetParent(transform, false);
                m_asBgm = objBgm.AddComponent<AudioSource>();
            }
        }

        m_asBgm.loop = true;
        m_asBgm.playOnAwake = false;
        m_asBgm.spatialBlend = 0f;
        m_asBgm.ignoreListenerPause = true;
        m_asBgm.volume = m_bIsMuted ? 0f : m_fBgmVolume;

        if (m_asBgm.clip == null)
        {
            m_asBgm.clip = CreateProceduralBgmClip();
        }

        if (!m_asBgm.isPlaying)
        {
            m_asBgm.Play();
        }

        if (m_asUiClick == null)
        {
            Transform trClick = transform.Find("UIClick_AudioSource");
            if (trClick != null)
            {
                m_asUiClick = trClick.GetComponent<AudioSource>();
            }
            if (m_asUiClick == null)
            {
                GameObject objClick = new GameObject("UIClick_AudioSource");
                objClick.transform.SetParent(transform, false);
                m_asUiClick = objClick.AddComponent<AudioSource>();
            }
        }

        m_asUiClick.loop = false;
        m_asUiClick.playOnAwake = false;
        m_asUiClick.spatialBlend = 0f;
        m_asUiClick.ignoreListenerPause = true;
        m_asUiClick.volume = m_bIsMuted ? 0f : m_fSfxVolume;

        if (m_asUiClick.clip == null)
        {
            m_asUiClick.clip = CreateProceduralClickClip();
        }
    }

    private AudioClip CreateProceduralBgmClip()
    {
        int nSampleRate = 22050;
        int nLengthSeconds = 4;
        int nTotalSamples = nSampleRate * nLengthSeconds;
        float[] arrSamples = new float[nTotalSamples];

        float[] arrChordFreqs = new float[] { 110.0f, 164.81f, 220.0f, 261.63f };
        for (int i = 0; i < nTotalSamples; i++)
        {
            float fTime = (float)i / nSampleRate;
            float fSignal = 0f;
            for (int c = 0; c < arrChordFreqs.Length; c++)
            {
                fSignal += Mathf.Sin(2f * Mathf.PI * arrChordFreqs[c] * fTime) * 0.06f;
            }
            float fLfo = 0.75f + 0.25f * Mathf.Sin(2f * Mathf.PI * 0.5f * fTime);
            arrSamples[i] = fSignal * fLfo;
        }

        AudioClip clipBgm = AudioClip.Create("ProceduralAmbientBGM", nTotalSamples, 1, nSampleRate, false);
        clipBgm.SetData(arrSamples, 0);
        return clipBgm;
    }

    private AudioClip CreateProceduralClickClip()
    {
        int nSampleRate = 22050;
        int nTotalSamples = nSampleRate / 20;
        float[] arrSamples = new float[nTotalSamples];

        for (int i = 0; i < nTotalSamples; i++)
        {
            float fTime = (float)i / nSampleRate;
            float fEnvelope = 1f - ((float)i / nTotalSamples);
            arrSamples[i] = Mathf.Sin(2f * Mathf.PI * 880f * fTime) * fEnvelope * 0.25f;
        }

        AudioClip clipClick = AudioClip.Create("ProceduralUiClick", nTotalSamples, 1, nSampleRate, false);
        clipClick.SetData(arrSamples, 0);
        return clipClick;
    }
}
